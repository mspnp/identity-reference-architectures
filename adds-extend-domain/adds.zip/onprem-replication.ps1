Configuration CreateReplication {
    param
    (
        [Parameter(Mandatory)]
        [string]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [Parameter(Mandatory)]
        [string]$SiteName,

        [Parameter(Mandatory=$True)]
        [string]$OnpremSiteName,
      
        [Parameter(Mandatory=$True)]
        [string]$Cidr,
      
        [Parameter(Mandatory=$True)]
        [int]$ReplicationFrequency
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDsc
    Import-DscResource -ModuleName ComputerManagementDsc

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WaitForADDomain DomainWait
        {
            DomainName = $DomainName
            Credential = $DomainCreds
            WaitForValidCredentials = $true
        }

        ADReplicationSite ReplicationSite
        {
            Name        = $SiteName
            Description = 'azure vnet ad site'
            DependsOn   = "[WaitForADDomain]DomainWait"
        }

        ADReplicationSubnet ReplicationSubnet
        {
            Name        = $Cidr
            Site        = $SiteName
            Location    = 'azure subnet location'
            Description = 'azure subnet description'
            DependsOn   = "[ADReplicationSite]ReplicationSite"
        }

        ADReplicationSiteLink ReplicationSiteLink
        {
            Name                          = 'AzureToOnpremLink'
            SitesIncluded                 = @($OnpremSiteName, $SiteName)
            Cost                          = 100
            ReplicationFrequencyInMinutes = $ReplicationFrequency
            DependsOn                     = "[ADReplicationSubnet]ReplicationSubnet"
        }

        PendingReboot RebootAfterReplication
        { 
            Name = "RebootAfterReplication"
            SkipWindowsUpdate           = $true
            SkipComponentBasedServicing = $false
            SkipPendingFileRename       = $false
            SkipPendingComputerRename   = $false
            SkipCcmClientSDK            = $false
            DependsOn = "[ADReplicationSiteLink]ReplicationSiteLink"
        }
   }
}